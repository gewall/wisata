

import cloudinary from "cloudinary";

cloudinary.v2.config({
    cloud_name: 'djh210frq', 
    api_key: '728812372824268', 
    api_secret: 'H9Yuxv_Oq-gNS1B1QxPpD6KZLzA' // Click 'View API Keys' above to copy your API secret
})

export default cloudinary